import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest

# =========================
# LOAD DATA
# =========================
df = pd.read_csv("data/network_data_raw.csv")

print("=== DATA AWAL ===")
print(df.head())

print("\n=== INFO DATA ===")
print(df.info())

print("\n=== DATA KOSONG ===")
print(df.isnull().sum())

# =========================
# CLEANING
# =========================
df = df.rename(columns={
    "Time": "timestamp",
    "Source": "src_ip",
    "Destination": "dst_ip",
    "Protocol": "protocol",
    "Length": "length"
})

df = df.dropna()

df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')

print("\n=== DATA SETELAH CLEANING ===")
print(df.head())

# =========================
# TRAFFIC ANALYSIS
# =========================
df['minute'] = df['timestamp'].dt.floor('min')

traffic = df.groupby('minute').size()

plt.figure()
traffic.plot(title="Traffic per Minute")
plt.tight_layout()
plt.show()

# =========================
# PROTOCOL ANALYSIS
# =========================
print("\n=== PROTOCOL DISTRIBUTION ===")
protocol_counts = df['protocol'].value_counts()
print(protocol_counts)

protocol_counts_df = protocol_counts.reset_index()
protocol_counts_df.columns = ['protocol', 'count']

plt.figure()
protocol_counts_df.plot(x='protocol', y='count', kind='bar', legend=False)
plt.title("Protocol Usage")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# =========================
# TOP SOURCE IP
# =========================
print("\n=== TOP SOURCE IP ===")
print(df['src_ip'].value_counts().head(10))

# =========================
# PACKET SIZE DISTRIBUTION
# =========================
plt.figure()
df['length'].plot(kind='hist', bins=20)
plt.title("Packet Size Distribution")
plt.tight_layout()
plt.show()

# =========================
# ANOMALY DETECTION (AI)
# =========================
model = IsolationForest(contamination=0.05, random_state=42)
df['anomaly'] = model.fit_predict(df[['length']])

print("\n=== ANOMALY DETECTED ===")
print(df[df['anomaly'] == -1].head())

# =========================
# ANOMALY VISUALIZATION
# =========================
plt.figure()
plt.scatter(df['timestamp'], df['length'], c=df['anomaly'])
plt.title("Anomaly Detection")
plt.tight_layout()
plt.show()

# =========================
# EXPORT DATA
# =========================
# Simpan ke CSV untuk backup atau penggunaan di file lain
df.to_csv("data/network_data_clean.csv", index=False)
print("\n[SUCCESS] Data bersih diekspor ke data/network_data_clean.csv")

# =========================
# INTEGRASI SQLITE (DATABASE)
# =========================
import sqlite3

# Membuat koneksi ke database (akan membuat file jika belum ada)
conn = sqlite3.connect('network_manager.db')

# Simpan DataFrame ke tabel 'traffic_logs'
# if_exists='replace' akan memperbarui tabel setiap kali script dijalankan
df.to_sql('traffic_logs', conn, if_exists='replace', index=False)

conn.close()
print("[SUCCESS] Data berhasil disimpan secara permanen di network_manager.db")