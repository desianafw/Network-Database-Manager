import streamlit as st
import pandas as pd
import sqlite3
import matplotlib.pyplot as plt

st.set_page_config(page_title="Network DB Manager", layout="wide")
st.title("🛡️ Network Database Dashboard")

def load_data_from_sqlite():
    try:
        # Hubungkan ke database yang dibuat oleh analysis.py
        conn = sqlite3.connect('network_manager.db')
        query = "SELECT * FROM traffic_logs"
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df
    except Exception as e:
        return None

# Load data
df = load_data_from_sqlite()

if df is not None:
    st.success("Data berhasil dimuat dari Database SQLite")
    
    # Metrik Ringkasan
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Log", len(df))
    col2.metric("Protokol Unik", df['protocol'].nunique())
    col3.metric("Rata-rata Size", f"{df['length'].mean():.2f} bytes")

    # Tabel Data
    st.subheader("Data Log Jaringan")
    st.dataframe(df, use_container_width=True)

    # Visualisasi Sederhana
    st.subheader("Distribusi Protokol")
    fig, ax = plt.subplots()
    df['protocol'].value_counts().plot(kind='pie', autopct='%1.1f%%', ax=ax)
    st.pyplot(fig)
else:
    st.warning("Database tidak ditemukan. Jalankan 'analysis.py' terlebih dahulu untuk generate data.")
