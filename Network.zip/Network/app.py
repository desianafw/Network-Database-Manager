import streamlit as st
import pandas as pd
import sqlite3
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest # Tambahan library untuk AI

st.set_page_config(page_title="Network DB Manager", layout="wide")
st.title("🛡️ Network Database Dashboard")

def load_data_from_sqlite():
    try:
        # Hubungkan ke database yang dibuat oleh analysis.py
        conn = sqlite3.connect('network_manager.db')
        query = "SELECT * FROM traffic_logs"
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df
    except Exception as e:
        return None

# Load data
df = load_data_from_sqlite()

if df is not None:
    st.success("Data berhasil dimuat dari Database SQLite")
    
    # Metrik Ringkasan
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Log", len(df))
    col2.metric("Protokol Unik", df['protocol'].nunique())
    
    # Memastikan kolom 'length' ada dan berupa angka sebelum dihitung rata-ratanya
    if 'length' in df.columns:
        df['length'] = pd.to_numeric(df['length'], errors='coerce').fillna(0)
        col3.metric("Rata-rata Size", f"{df['length'].mean():.2f} bytes")

    # Tabel Data
    st.subheader("Data Log Jaringan")
    st.dataframe(df, use_container_width=True)

    # Visualisasi Sederhana
    st.subheader("Distribusi Protokol")
    if 'protocol' in df.columns:
        fig, ax = plt.subplots()
        df['protocol'].value_counts().plot(kind='pie', autopct='%1.1f%%', ax=ax)
        st.pyplot(fig)

    # ==========================================================
    # 🔮 AI PREDICTIVE ANALYSIS SECTION (BARU)
    # ==========================================================
    st.markdown("---")
    st.title("🔮 AI Predictive Analysis: Anomaly Detection")
    st.write("Model Machine Learning (Isolation Forest) menganalisis ukuran paket (length) untuk mendeteksi aktivitas jaringan yang tidak wajar.")

    if 'length' in df.columns and len(df) > 0:
        with st.spinner("AI sedang menganalisis traffic..."):
            # 1. Inisialisasi Model AI
            # contamination=0.05 artinya AI berasumsi maksimal 5% dari traffic adalah anomali
            ai_model = IsolationForest(contamination=0.05, random_state=42)
            
            # 2. Latih model dan lakukan prediksi
            # Menggunakan double bracket [['length']] karena scikit-learn butuh format 2D array
            df['is_anomaly'] = ai_model.fit_predict(df[['length']])
            
            # 3. Filter data (Hasil prediksi: 1 = Normal, -1 = Anomali)
            anomalies = df[df['is_anomaly'] == -1]
            
            # 4. Tampilkan Hasil
            if not anomalies.empty:
                st.error(f"🚨 ALERT: AI mendeteksi {len(anomalies)} aktivitas jaringan yang berpotensi anomali!")
                
                # Tampilkan tabel anomali
                st.write("**Detail Log Anomali:**")
                st.dataframe(anomalies.drop(columns=['is_anomaly']), use_container_width=True)
                
                # Visualisasi Scatter Plot untuk Anomali
                st.write("**Visualisasi Anomali (Titik Merah)**")
                fig_ai, ax_ai = plt.subplots(figsize=(10, 4))
                
                # Plot data normal (biru)
                normal_data = df[df['is_anomaly'] == 1]
                ax_ai.scatter(normal_data.index, normal_data['length'], color='blue', alpha=0.5, label='Normal Traffic')
                
                # Plot data anomali (merah)
                ax_ai.scatter(anomalies.index, anomalies['length'], color='red', label='Anomaly Traffic')
                
                ax_ai.set_ylabel("Packet Length (Bytes)")
                ax_ai.set_xlabel("Log Index")
                ax_ai.legend()
                st.pyplot(fig_ai)
            else:
                st.success("✅ AI Analysis: Jaringan terpantau aman. Tidak ada anomali yang terdeteksi.")
    else:
        st.warning("Kolom 'length' tidak ditemukan atau data kosong. AI butuh data ukuran paket untuk bekerja.")

else:
    st.warning("Database tidak ditemukan. Jalankan 'analysis.py' terlebih dahulu untuk generate data.")