from sklearn.ensemble import IsolationForest
import joblib

def train_anomaly_model(df, contamination=0.05):
    # Menggunakan fitur length dan mungkin fitur numerik lain nantinya
    model = IsolationForest(contamination=contamination, random_state=42)
    model.fit(df[['length']])
    # Simpan model agar bisa dipakai di app.py tanpa train ulang
    joblib.dump(model, "network_anomaly_model.pkl")
    return model

def predict_anomalies(model, df):
    return model.predict(df[['length']])